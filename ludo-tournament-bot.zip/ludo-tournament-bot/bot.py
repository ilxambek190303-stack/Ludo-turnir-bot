import logging
from telegram.ext import ApplicationBuilder

from config import BOT_TOKEN
from database.models import init_db
from handlers import shop, referral, tournament

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


def main():
    if not BOT_TOKEN:
        raise RuntimeError(
            "BOT_TOKEN topilmadi! .env faylida BOT_TOKEN=... qo'ying (BotFather'dan olingan token)."
        )

    init_db()

    app = ApplicationBuilder().token(BOT_TOKEN).build()

    referral.register(app)
    shop.register(app)
    tournament.register(app)

    logger.info("Bot ishga tushdi...")
    app.run_polling()


if __name__ == "__main__":
    main()
