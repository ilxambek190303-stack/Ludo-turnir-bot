# Ludo Turnir Bot

Guruh uchun Ludo King uslubidagi turnir + skin do'kon + referral (do'st taklif qilish) boti.

## Xususiyatlari

- 🎲 Do'kon: kublar, tokenlar (figuralar), taxta temalari — Ludo King skinlariga o'xshash
- 🔗 Referral tizimi: do'st taklif qilsangiz coin va maxsus skinlar ochiladi
- 🏆 Turnir: guruhda ro'yxatdan o'tish, boshlash, g'olibni e'lon qilish
- 💰 Coin balansi va reyting jadvali

## O'rnatish

1. Reponi klonlang:
```bash
git clone https://github.com/USERNAME/ludo-tournament-bot.git
cd ludo-tournament-bot
```

2. Kerakli kutubxonalarni o'rnating:
```bash
pip install -r requirements.txt
```

3. `.env.example` faylini `.env` deb nomlang va o'zingizning ma'lumotlaringizni kiriting:
```bash
cp .env.example .env
```
`.env` ichida:
```
BOT_TOKEN=SizningBotFatherdanOlganTokeningiz
BOT_USERNAME=SizningBotUsernameingiz
```

> Botni yaratish uchun Telegram'da [@BotFather](https://t.me/BotFather) ga yozing, `/newbot` buyrug'ini bering, token oling.

4. Botni ishga tushiring:
```bash
python bot.py
```

## Buyruqlar

| Buyruq | Vazifasi |
|---|---|
| `/start` | Botni ishga tushirish, taklif linkini olish |
| `/shop` | Do'konni ochish (kub, token, tema) |
| `/profil` | Hisobingizni ko'rish |
| `/taklif` | Referral linkingizni olish |
| `/reyting` | Top o'yinchilar |
| `/turnir` | Guruhda turnir ochish |
| `/golib <user_id>` | (Admin) Turnir g'olibini e'lon qilish |
| `/oynadim` | Faollikni qayd etish (referral bonusi uchun) |

## Serverga qo'yish (deploy)

Bepul variantlar:
- **Railway.app** — GitHub repo'ni ulaysiz, `BOT_TOKEN` ni Environment Variables'ga qo'shasiz, avtomatik ishga tushadi
- **Render.com** — "Background Worker" turida deploy qiling
- **VPS** (masalan Timeweb, Contabo) — `screen` yoki `systemd` orqali doimiy ishga tushiring

## Fayl tuzilishi

```
ludo-tournament-bot/
├── bot.py                  # asosiy ishga tushirish fayli
├── config.py                # sozlamalar (coin miqdorlari va h.k.)
├── database/
│   ├── models.py             # SQLite bazasi bilan ishlash
│   └── shop_data.py          # skinlar katalogi
├── handlers/
│   ├── referral.py           # /start, /taklif, /profil, /reyting
│   ├── shop.py                # /shop va sotib olish logikasi
│   └── tournament.py          # /turnir va /golib
├── requirements.txt
├── .env.example
└── .gitignore
```

## Skinlarni o'zgartirish

`database/shop_data.py` faylida har bir skin uchun narx (`price`, coin) va kerakli taklif soni
(`referrals`) ni o'zingizga moslab o'zgartirishingiz mumkin. Yangi skin qo'shish uchun
shunchaki lug'atga yangi qator qo'shsangiz bo'ldi:

```python
"Yangi Skin": {"price": 1000, "referrals": 3},
```
